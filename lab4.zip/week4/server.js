const express = require("express");
const app = express();
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
app.use(express.static('views'));
app.use(express.static('images'));
app.use(express.static('css'));
app.use(express.urlencoded({
    extended: true
}));
app.use(express.json());


let db = [];

app.get('/', function (req, res) {
    res.render('homepage.html');
});

app.get('/addbook', function (req, res) {
    res.render("newbook.html");
    
})
app.get('/listbook', function (req, res) {
    res.render("listbooks.html", {db:db});
    
})

app.get('/*',function(req,res){
    res.render("404.html")
})

app.post('/addbook', function (req, res) {
    let title = req.body.title;
    let author = req.body.author;
    let topic = req.body.topic;
    let cost = parseFloat(req.body.cost);

    if ((title.length > 2) && (author.length > 2) && (topic.length > 2) && cost >= 0){
        let newRec = {
            title: title,
            author: author,
            topic: topic,
            cost: cost,
        };
        db.push(newRec);
    } else {
        res.render("invaliddata.html");
    }
    console.log(db);
    res.render("newbook.html");
})


// app.post('/addbooks', function (req, res) {
    
//     res.render("newbook.html");
// })

app.listen(8080);