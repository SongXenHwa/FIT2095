const mongoose = require('mongoose');

let doctorSchema = mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,
    fullname: {
        firstName:{
            type: String,
            required: true,
        },
        lastName: {
            type: String,
        }
    },
    dob: {
        type: Date,
    },
    address:{
        state: {
            type: String,
            validate: {
                validator: function(newState){
                    return newState.length > 1 && newState.length < 4;
                },
                message: 'State should be in between 2 and 3 char'
            }
        },
        suburb:{
            type: String,
        },
        street: {
            type: String,
        },
        unit: {
            type: Number,
        }
    },
    numPatients: {
        type: Number,
        validate: {
            validator: function(noPatients){
                return noPatients >= 0;
            },
            message: 'Number of patients should be a positive value'
        }
    }

});

module.exports = mongoose.model('Doctor',doctorSchema);