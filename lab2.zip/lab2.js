var http = require('http');
var fs = require('fs');

const port = 8080;

function getDaysDiff(d, m, y) {
    let returnValue = -1;
    let currentDay = new Date();
    currentDay.setDate(parseInt(d));
    currentDay.setMonth(parseInt(m) - 1); // months start from 0
    currentDay.setYear(parseInt(y));
    let firstDay = new Date("8/3/2020"); // first day in semester 2
    if (currentDay >= firstDay) {
        var diffDays = parseInt((currentDay - firstDay) / (1000 * 60 * 60 * 24)); //gives day difference 
        returnValue = (Math.floor(diffDays / 7) + 1);
    }
    return (returnValue);
}
// let fileName = 'index.html';
http.createServer(function (request, response) {
    let url = request.url;
    var baseURL = "http://" + request.headers.host + "/";
    var urlObj = new URL(request.url, baseURL);
    var check = new Boolean(true);

    console.log('request ', urlObj.pathname);
    switch (urlObj.pathname) {
        case '/':
            fileName = 'index.html';
            break;
        case '/lab2assessments': 
            fileName = 'lab2assessments.html';
            break;
        case '/lab2topics':
            fileName = 'lab2topics.html';
            break;
        case '/whichweek/':
            check = false;
            let params = urlObj.searchParams;
            let day = params.get("d");
            let mon = params.get("m");
            let yr = params.get("y");
            let temp = getDaysDiff(day,mon,yr);
            console.log(temp);

            if (temp < 0){
                response.end( "Uni has not start on this date. It start on the 3 August 2020.");
            }else if(temp > 14){
                response.end("Uni has already ended. Last day of uni is 6 November 2020");
            }else{
                response.end("It is currently in week " + temp + " of uni.")
            }
            
            break;

        default:
            fileName = '404.html';
            break;
    }
    if (check){
        fs.readFile(fileName, function (error, content) {
            response.writeHead(200, {
                'Content-Type': 'text/html'
            });
            response.end(content, 'utf-8');
        });
    }
}).listen(port);
