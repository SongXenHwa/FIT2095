const express = require("express");
const mongodb = require("mongodb");
const morgan = require("morgan");
const ejs = require("ejs");
//Configure Express
const app = express();
app.engine("html", ejs.renderFile);
app.set("view engine", "html");
app.use(express.static("public"));
app.use(express.static('views'));
app.use(express.static('css'));
app.use(express.static('images'));
app.use(express.urlencoded({ extended: false }));
app.use(morgan("common"));
app.listen(8080);
const MongoClient = mongodb.MongoClient;
const url = "mongodb://localhost:27017/";

let db;

MongoClient.connect(url, { useNewUrlParser: true }, function (err, client) {
    if (err) {
      console.log("Err  ", err);
    } else {
      console.log("Connected successfully to server");
      db = client.db("fit2095");
    }
});

app.get("/", function (req, res) {
  res.sendFile(__dirname + "/views/index.html");
});

app.post("/addnewbook", function (req, res) {
  db.collection("books").insertOne({
      title: req.body.btitle,
      author: req.body.bauthor,
      topic: req.body.btopic,
      dop: req.body.bdop,
      summary : req.body.bsummary,
  });
  res.redirect("/getbooks"); // redirect the client to list users page
});

app.get("/getbooks", function (req, res) {
  db.collection("books")
      .find({})
      .toArray(function (err, data) {
      res.render("listbooks", { bookDb: data });
      });
});

app.get("/updatebook", function (req, res) {
  res.render("updatebook");
});

app.get("/deletebook", function (req, res) {
  res.render("deletebook");
});

app.get("/getbooks", function (req, res) {
  db.collection("books")
      .find({})
      .toArray(function (err, data) {
      res.render("listbooks", { bookDb: data });
      });
});

app.post("/updatebookdata", function (req, res) {
  let filter = { title: req.body.btitle };
  let theUpdate = {
    $set: {
      title: req.body.btitle,
      author: req.body.bauthor,
      topic: req.body.btopic,
      dop: req.body.bdop,
      summary : req.body.bsummary,
    },
  };
  db.collection("books").updateOne(filter, theUpdate);
  res.redirect("/getbooks"); 
});

app.post("/deletebookdata", function (req, res) {
  db.collection("books").deleteMany({topic : req.body.btopic});
  res.redirect("/getbooks");
});