let express = require('express');
let app = express();
let db = [];

app.get('/', function (req, res) {
    let msg = "Week 3 lab";
    res.send(msg);
});

// add a new book to the array and display the book added as an output in json format
app.get("/addbook", function (req, res) {
    let baseURL = "http://" + req.headers.host + "/";
    let url = new URL(req.url, baseURL);
    let params = url.searchParams;
    console.log(params);
    let newRec = {
        id: generateRandomID(),
        title: params.get("title"),
        author: params.get("author"),
        topic: params.get("topic"),
        cost: params.get("cost"),
    };
    db.push(newRec);
    res.send(newRec);
});

// app.get("/addbook/:title/:author/:topic/:cost", function (req, res) {
//     let newRec = {
//         id: generateRandomID(),
//         title: req.params.title,
//         author: req.params.author,
//         topic: req.params.topic,
//         cost: req.params.cost,
//     };
//     db.push(newRec);
//     res.send(newRec);
// });



// output a list consisting all the book in the database array
app.get("/getallbooks", function (req, res) {
    res.send(generateList());
});

// delete book in the array which id is in the url
app.get('/deleteid/:bookIndex', function (req, res) {
    deleteBookById(req.params.bookIndex);
    res.send(generateList());
});

// get the total cost of all the book in the array
app.get('/getbookstorevalue', function (req, res) {
    let temp = bookStoreValue();
    res.send("The book store value is $" + temp);
});

app.get('/reducebookcost/:percentage', function (req, res) {
    reduceBookCost(req.params.percentage);
    res.send(generateList());
});
app.listen(8080);

// function to generate and print the list of books in the array
function generateList() {
    let st = 'BookID   Title   Author   Topic   Cost</br>';
    for (let i = 0; i < db.length; i++) {
        st += db[i].id + ' | ' + db[i].title + ' | ' + db[i].author + ' | ' + db[i].topic + ' | ' + db[i].cost + '</br>';
    }
    return st;
};

// create a random id for new book inserted to the array ranging between 0-1000
function generateRandomID(){
    let newId= Math.round(Math.random()*1000);
    return newId;
};

// delete the book with id mathcing the param given in the array
function deleteBookById(id){
    for (let i = 0 ; i < db.length; i ++){
        if(db[i].id == id){
            db.splice(i,1);
            break;
        }
    }
};

// go through the array and add the cost of each book
function bookStoreValue(){
    let res = 0;
    for (let i = 0 ; i < db.length; i ++){
        res += parseInt(db[i].cost);
    }
    return res;
};


function reduceBookCost(percent){
    for (let i = 0 ; i < db.length; i ++){
        let temp = parseFloat(db[i].cost);
        let discount = temp * (percent / 100);
        let res = temp - discount;
        if (res > -1){
            db[i].cost = temp - discount;
        }
    }
};